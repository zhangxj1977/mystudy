﻿-------------------------------------------------------------------
【ソフト名】 A5:SQL Mk-2 Version 2.9.1
【制作者名】 松原正和
【動作環境】 Windows 2000 SP4
             Windows XP
             Windows Vista
             Windows 7
             Windows 8
             Windows Server 2003
             Windows Server 2008
             Windows Server 2012 (GUI 使用サーバー)

             ※ x86版は 64bit OLE DB, ODBCには接続出来ません。
             ※ x64版は 32bit OSでは動作しません。
             ※ x64版は 32bit OLE DB, ODBCには接続出来ません。
【  種別  】 ビジネス/データベース関連ソフトウェア
【 連絡先 】 下記URLにアクセスしてトップページに記載されるメール
              アドレスにメールを送信してください。
【 ＵＲＬ 】 http://www.wind.sannet.ne.jp/m_matsu/
【ファイル】x86版 : a5m2_2.9.1_x86.zip
            x64版 : a5m2_2.9.1_x64.zip
            x86版(読み取り専用版) : a5m2_2.9.1_x86_r.zip
            x64版(読み取り専用版) : a5m2_2.9.1_x64_r.zip
-------------------------------------------------------------------

■概要
    A5:SQL Mk-2は複雑化するデータベース開発を支援するために開発されたフリー
  のSQL開発環境&ER図開発ツールです。
    高機能かつ軽量で、使い方が分かりやすいことを目標に開発されています。
    SQLを実行したり、テーブルを編集するほかに、SQLの実行計画を取得したり、ER
  図を作成したりするなど多彩な機能を持ちます。


■ファイル
  アーカイブファイルには以下のファイルが含まれます。
  ・A5M2.exe                          A5:SQL Mk-2 実行ファイル
  ・dbexpmda40.dll                    MySQL 接続用ライブラリ
  ・dbexpoda40.dll                    Oracle OCI接続用ライブラリ
  ・dbexpoda40d.dll                   Oracle 直接接続用ライブラリ(dbexpoda40.dllと同じもの)
  ・dbexppgsql40.dll                  PostgreSQL 直接接続用ライブラリ
  ・dbexpsda40.dll                    MySQL接続用ライブラリ
  ・gdiplus.dll                       GDI+ ダイナミックリンクライブラリファイル (x86版のみ)
  ・history.txt                       変更履歴
  ・license.txt                       ライセンス定義ファイル
  ・midas.dll                         データアクセスライブラリ (x64版のみ)
  ・readme.txt                        このファイル
  ・sample\*                          各種サンプル
  ・scripts\*                         スクリプトファイルのサンプル
  ・VirusCheck.txt                    アンチウイルスソフトにおける各ファイルのチェック結果ファイル


■OS、配布ファイル以外に必要なソフト
    Windows 2000 の場合は Microsoft Data Access Components 2.6 以上


■インストール
    インストール作業は必要ありません。
    ZIPファイルを展開し、A5M2.exeを起動することで使用できます。


■アップグレード
    インストールと同様にZIPファイルを展開し、A5M2.exeを起動することで使用で
  きます。
    ZIPファイルの展開は古いバージョンとは別のフォルダに展開してください。


■アンインストール
【x86版・x86版(読み取り専用版)】
    ZIPファイルを展開したフォルダを削除します。
    レジストリエディタから\\HKEY_CURRENT_USER\Software\mmatsubara\a5m2(x86)
  を削除してください。
    %APPDATA%\a5m2(x86) で表されるディレクトリ(%APPDATA%は環境変数)を削除し
  てください
    （ディレクトリ・レジストリの削除は必須ではありません）

【x64版・x64版(読み取り専用版)】
    ZIPファイルを展開したフォルダを削除します。
    レジストリエディタから\\HKEY_CURRENT_USER\Software\mmatsubara\a5m2(x64)
  を削除してください。
    %APPDATA%\a5m2(x64) で表されるディレクトリ(%APPDATA%は環境変数)を削除し
  てください
    （ディレクトリ・レジストリの削除は必須ではありません）


■使用方法
    初回起動時にデータベース登録画面が表示されます。そこから利用する
  データベースを登録します。
    通常はADO接続で利用しますが、OracleはOCI経由又は直接接続を、MySQLや、
  PostgreSQLは直接接続を利用することが出来ます。
    それが終わったら、左側のツリーより各データベースへ接続し、テーブル・
  ビュー・シノニム及びストアドプロシージャへアクセスできます。
    SQL(S) のメニューより新規作成を選ぶことでSQL文がテストできるように
  なります。このウインドウではselect文、やその他のDML文(Insert, Update, 
  Delete)が実行できます。接続先のRDBMSが提供する構文でDDL文も実行可能です。
  
  以下に大まかな機能一覧を示します。
  ・ADOやODBCを介したDBへの接続
    （Oracle, PostgreSQL, MySQLへは直接接続できます）
  ・SQL入力補完機能（共通表式やサブクエリも解析）
  ・SQLをGUIで作成・編集する機能
  ・実行計画取得機能
  ・SQL整形機能
  ・";"(セミコロン)または行頭の"/"(スラッシュ)や"GO"で区切ったSQLの連続実行
  ・複数の結果セットをまとめて Excel へ出力
  ・SQLを２回実行して差を Excel へ出力（複数結果セットの比較も可能）
  ・パラメータを使ったSQLの実行
  ・テーブルやクエリー結果セットのフィルタリング（絞込み）
  ・クエリーのコメント中にカラム名や結果セットのタイトルなどを指定する擬似命  
    令を埋め込む機能
  ・Excelと連携可能なテーブルエディタ
  ・テーブルのプロパティ（RDBMSごとの追加情報）を表示
  ・テーブルのソースを表示
  ・テーブル内容のエクスポート・インポート
  ・テーブルに大量のテスト用ダミーデータをインサートする機能
  ・ER図を作成する機能
  ・データベースからER図を作成する機能
  ・ER図からデータベースのDDLを作成する機能
  ・スクリプト言語機能

  詳しくは以下のサイトを参照してください。
  http://www.wind.sannet.ne.jp/m_matsu/developer/a5m2/


■利用しているプログラム部品について
    A5:SQL Mk-2では以下のプログラム部品（コンポーネント・ライブラリ）を利用
  させていただいております。作者の皆様に心より感謝いたします。

  ・ActiveQueryBuilder Ver 1.17           Active Database Software 社様 (有償)
  ・dbexpmda40.dll Ver 4.70               Devart 社様 (有償)
  ・dbexpoda40.dll Ver 4.90               Devart 社様 (有償)
  ・dbexppgsql40.dll Ver 2.0              Devart 社様 (有償)
  ・dbexpsda40.dll Ver 6.2.3              Devart 社様 (有償)
  ・SecureBridge Ver 4.1.3                Devart 社様 (有償)
  ・DCPcrypt v2.0.4.1                     David Barton 様
  ・DMonkey Version: 0.3.9                Project DMonkey 様
  ・GDI+ API, GDI+ Class, GDI+ Util       http://www.progdigy.com 様                              
  ・NkPrinter(0.53)                       T.Nakamura 様
  ・Syntax Editor SDK v 2.6.0             EControl 社様 (有償)
  ・TCtrlGridコンポーネント  Ver 2.10     ＳＵＮ 様
  ・TSyntaxEditor Ver 2.60                EControl 社様
  ・ファイルドロップコンポーネント v1.00  米田 昌司 様
  ・フォント名コンボボックス(＆リストボックス) Version 1.2.1
                                          加藤太朗 様
  ・MECSUtils Ver 1.50                    DEKO 様
